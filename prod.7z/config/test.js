const sequConnection = require('./dbConnection')
const dotenv = require('dotenv');
require('dotenv').config();
var res = process.env;
console.log(res)