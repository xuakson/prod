/**
 * app.js
 * Use `app.js` to run your app.
 * To start the server, run: `node app.js`.
 */

const express = require('express');
const session = require('express-session');
const cors = require('cors');
const path = require('path');
const dotenv = require('dotenv');
const postmanToOpenApi = require('postman-to-openapi');
const swaggerUi = require('swagger-ui-express');
const YAML = require('yamljs');
dotenv.config({ path: '.env' });
global.__basedir = __dirname;
const listEndpoints = require('express-list-endpoints');
const passport = require('passport');
require('./utils/dbService');

const models = require('./model');

const seeder = require('./seeders');
const routes =  require('./routes');
let logger = require('morgan');

const { devicePassportStrategy } = require('./config/devicePassportStrategy');
const { adminPassportStrategy } = require('./config/adminPassportStrategy');
const { linkedinPassportStrategy } = require('./config/linkedinPassportStrategy');
const { googlePassportStrategy } = require('./config/googlePassportStrategy');

const app = express();
app.use(require('./utils/response/responseHandler'));

const corsOptions = { origin: process.env.ALLOW_ORIGIN, };
app.use(cors(corsOptions));

//template engine
app.set('view engine', 'ejs'); 
app.set('views', path.join(__dirname, 'views'));

devicePassportStrategy(passport);
adminPassportStrategy(passport);
linkedinPassportStrategy(passport);
googlePassportStrategy(passport);

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(passport.initialize());
app.use(session({
  secret:'my-secret',
  resave:true,
  saveUninitialized:false
}));

app.get('/', (req, res) => {
  res.render('index');
});

if (process.env.NODE_ENV !== 'test') {
  
  models.then((model) => {

    // model.sequelize.sync({ alter:true }).then(()=>{
        
    // }).catch(err => {
    //   console.error("Error syncing database:", err);
    // }).finally(() => {
    //   app.use(routes);
    //   const allRegisterRoutes = listEndpoints(app);
    //   seeder(allRegisterRoutes).then(()=>{console.log('Seeding done.');});
    //   //swagger Documentation
    //   postmanToOpenApi('postman/postman-collection.json', path.join('postman/swagger.yml'), { defaultTag: 'General' }).then(data => {
    //     let result = YAML.load('postman/swagger.yml');
    //     result.servers[0].url = '/';
    //     app.use('/swagger', swaggerUi.serve, swaggerUi.setup(result));
    //   }).catch(e=>{
    //     console.log('Swagger Generation stopped due to some error');
    //   });
    // });
    app.use(routes);
    const allRegisterRoutes = listEndpoints(app);
    postmanToOpenApi('postman/postman-collection.json', path.join('postman/swagger.yml'), { defaultTag: 'General' }).then(data => {
      let result = YAML.load('postman/swagger.yml');
      result.servers[0].url = '/';
      app.use('/swagger', swaggerUi.serve, swaggerUi.setup(result));
    }).catch(e=>{
      console.log('Swagger Generation stopped due to some error');
    });
    app.listen(process.env.PORT,()=>{
      console.log(`your application is running on ${process.env.PORT}`);
    });
  })
 
} else {
  module.exports = app;
}
